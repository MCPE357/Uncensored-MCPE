# Uncensored-MCPE
# This apk allows you to swear without censoring by microsoft!
# Report system doesn't work
# Todo: remove ban, remove report button (currently the game crashes)
